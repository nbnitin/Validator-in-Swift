//
//  SwiftValidator.h
//  SwiftValidator
//
//  Created by Rusty Zarse on 9/3/15.
//  Copyright (c) 2015 jpotts18. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftValidator.
FOUNDATION_EXPORT double SwiftValidatorVersionNumber;

//! Project version string for SwiftValidator.
FOUNDATION_EXPORT const unsigned char SwiftValidatorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftValidator/PublicHeader.h>


